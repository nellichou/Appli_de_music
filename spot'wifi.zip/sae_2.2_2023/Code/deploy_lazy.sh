# Clean the server side
rm -rf ~/public_html/SAE/application/*

cp -r ~/sae/SAE_2.2_2023/application/* ~/public_html/SAE/application/