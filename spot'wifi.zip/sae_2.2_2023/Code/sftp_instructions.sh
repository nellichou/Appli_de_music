rmdir public_html/SAE/application
put -r ../application/* public_html/SAE/application/
exit