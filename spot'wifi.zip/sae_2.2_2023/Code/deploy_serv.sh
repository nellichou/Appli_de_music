# Reinstall CodeIgniter if needed
if [[-d ~/public_html/SAE/system]] do 
	rm -rf ~/public_html/* #nuke it
	cp ~/sae/Codegniiter/system ~/public_html/
	cp ~/sae/Codegniiter/index.php ~/public_html/
done	
# Clean the server side
rm -rf ~/public_html/app/*
rm -rf ~/public_html/public/*
# Pull a clean copy from Git
git pull
# Move the files freshly imported
cp ./app/* ~/public_html/app/*
cp ./public/* ~/public_html/public/*/*
# Set the correct variables
$mdp = echo ~/DEV/DEV2.2/mariadb.txt
sed  -i "s/STRING_TO_REPLACE/$mdp/" ~/public_html/application/config/database.php