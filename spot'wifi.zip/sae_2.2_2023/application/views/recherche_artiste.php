<h5>Recherche par Artiste</h5>

<article class="container">

<?=form_open('recherche/resultat/artiste',['method'=>'get'])?>
	<div class="grid">
		<input placeholder="Rechercher un Artiste" type="search"  name="recherche" value ="" required>
		<button type="submit" >Rechercher</button>
	</div>
</form>
</article>	
	

