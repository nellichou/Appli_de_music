<h5>Genre list</h5>

<?php
if (!isset($choix)) {
    $choix =  'ancien';
}
?>

<article class="container">
			Choisissez un tri :
			<?=form_open('genres/index',['method'=>'get'])?>
				<select name="choix" id="choix" required>
					<option value="AZ"<?php echo ($choix == 'AZ') ? ' selected' : ''; ?>>A-Z</option>
					<option value="ZA"<?php echo ($choix == 'ZA') ? ' selected' : ''; ?>>Z-A</option>
				</select>
				<button type="submit"> Valider</button>
					
			</form>
</article>

<section class="list">
<?php
foreach($genres as $genre){
	echo "<div><article>";
	echo "<header class='short-text'>";
	echo anchor("genres/view/{$genre->genreId}","{$genre->genreName}");
	echo "</header></article></div>";
}


?>
</section>