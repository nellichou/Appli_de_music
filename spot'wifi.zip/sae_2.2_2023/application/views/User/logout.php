<article class="container">
        <h2>Déconnexion réussie</h2>
        <a href="<?php echo site_url('Utilisateur/login'); ?>" class="contrast">Se reconnecter</a>
    </article>